import { createContext } from 'react'

const PopUpContext = createContext(null);
export default PopUpContext;
