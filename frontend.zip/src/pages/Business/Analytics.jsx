import React from "react";

const Analytics = () => {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Analytics</h2>
      <p>Analyze the performance of your offers and track metrics.</p>
      {/* Add analytics charts and metrics here */}
    </div>
  );
};

export default Analytics;