import React from 'react';

export default function CustomerSupport() {
  return (
    <div>
      <h1>Customer Support</h1>
      <p>Need help? Contact our customer support team or browse our FAQ section.</p>
    </div>
  );
}